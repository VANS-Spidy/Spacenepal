/*
Spacenepal - VENOM ASSOCIATED NETWORK SYSTEM

Copyright 20017-2018 Sundeep Adhikari

This file is part of Spacenepal.

Spacenepal is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Spacenepal is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Spacenepal.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.Spacenepal.model;

/**
 * Helper class for constants used for bundle params (extras)
 * 
 * @author Sundeep Adhikari <connectme@spacenepal.com>
 */
public class Extra
{
    public static final String SERVER            = "server";
    public static final String CONVERSATION      = "conversation";
    public static final String USERS             = "users";

    public static final String ALIASES           = "aliases";
    public static final String CHANNELS          = "channels";
    public static final String COMMANDS          = "commands";
    public static final String MESSAGE           = "message";
    public static final String USER              = "user";
    public static final String ACTION            = "action";

    public static final String NICKSERV_PASSWORD = "nickserv_password";
    public static final String SASL_USER         = "sasl_user";
    public static final String SASL_PASSWORD     = "sasl_password";

    public static final String CONNECT           = "connect";
    public static final String SERVER_ID         = "serverId";
}
