/*
Spacenepal - VENOM ASSOCIATED NETWORK SYSTEM

Copyright 20017-2018 Sundeep Adhikari

This file is part of Spacenepal.

Spacenepal is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Spacenepal is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Spacenepal.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.Spacenepal.model;

/**
 * An IRC channel (extends Conversation)
 * 
 * @author Sundeep Adhikari <connectme@spacenepal.com>
 */
public class Channel extends Conversation
{
    private String topic;

    /**
     * Create a new channel object
     * 
     * @param name of the channel
     */
    public Channel(String name)
    {
        super(name);
        this.topic = "";
    }

    /**
     * Get the type of this conversation
     */
    @Override
    public int getType()
    {
        return Conversation.TYPE_CHANNEL;
    }

    /**
     * Set the channel's topic
     * 
     * @param topic The topic of the channel
     */
    public void setTopic(String topic)
    {
        this.topic = topic;
    }

    /**
     * Get the topic of the channel
     * 
     * @return The channel's topic
     */
    public String getTopic()
    {
        return topic;
    }
}
