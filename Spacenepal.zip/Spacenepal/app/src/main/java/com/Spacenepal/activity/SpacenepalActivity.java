/*
Spacenepal - VENOM ASSOCIATED NETWORK SYSTEM

Copyright 20017-2018 Sundeep Adhikari

This file is part of Spacenepal.

Spacenepal is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Spacenepal is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Spacenepal.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.Spacenepal.activity;

import android.support.v7.widget.Toolbar;

import com.Spacenepal.irc.IRCBinder;
import com.Spacenepal.model.Server;

/**
 * Interface for fragments accessing functionality of the main activity.
 */
public interface SpacenepalActivity {
    IRCBinder getBinder();

    Toolbar getToolbar();

    void setToolbarTitle(String title);

    void onServerSelected(Server server);
}
