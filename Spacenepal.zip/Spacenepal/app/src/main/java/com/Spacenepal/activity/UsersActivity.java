/*
Spacenepal - VENOM ASSOCIATED NETWORK SYSTEM

Copyright 20017-2018 Sundeep Adhikari

This file is part of Spacenepal.

Spacenepal is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Spacenepal is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Spacenepal.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.Spacenepal.activity;

import java.util.Arrays;

import com.Spacenepal.R;
import com.Spacenepal.model.Extra;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;

/**
 * User Activity - Shows a list of users in the current channel
 * 
 * @author Sundeep Adhikari <connectme@Spacenepal.org>
 */
public class UsersActivity extends ListActivity implements OnItemClickListener
{
    /**
     * On create
     */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.users);

        final String[] users = getIntent().getExtras().getStringArray(Extra.USERS);
        getListView().setOnItemClickListener(this);

        // Add sorted list of users in own thread to avoid blocking UI
        // TODO: Move to a background task and show loading indicator while sorting
        Arrays.sort(users, String.CASE_INSENSITIVE_ORDER);
        getListView().setAdapter(new ArrayAdapter<String>(UsersActivity.this, R.layout.useritem, users));
    }

    /**
     * On user selected
     */
    @Override
    public void onItemClick(AdapterView<?> list, View item, int position, long id)
    {
        Intent intent = new Intent();
        intent.putExtra(Extra.USER, (String) getListView().getAdapter().getItem(position));
        setResult(RESULT_OK, intent);
        finish();
    }
}
